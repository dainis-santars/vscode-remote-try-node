import re
with open("kaza-un-vilks.txt") as txt:
  data = txt.read()
#Vai pasaka sākas ar reiz?
reiz = re.match(r'Reiz',data)
if reiz is not None:
  print("Pasaka sākas ar Reiz")
else:
  print("Pasaka nesākas ar Reiz")
#Cik reizes atkārtojas vārds un?
un = re.findall(r'un',data)
print("Vārds un atkārtojas",len(un),"reizes.")
#Vārdi, kas beidzas ar us
us = re.findall(r'\w*us\b', data)
for i in us:
  print(i)
#Vismaz 10 burtus gari vārdi
desmit = re.findall(r'\b\w{10,}\b',data)
for d in desmit:
  print(d)