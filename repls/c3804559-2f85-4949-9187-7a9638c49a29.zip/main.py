
import osmnx as ox
ox.plot_graph(ox.graph_from_place('Rēzekne, Latvija'))