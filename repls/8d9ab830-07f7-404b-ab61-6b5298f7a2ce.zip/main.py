# print("es","esmu","kļavas","lapa")
# a = 'A'
# a1k = a * 1000
# print(a1k)
s = "liliputi"
i = "l"
sk = s.count(i)
print(sk)