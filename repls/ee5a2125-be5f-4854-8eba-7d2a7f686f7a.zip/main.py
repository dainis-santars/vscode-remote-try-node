# https://www.ss.lv/msg/lv/transport/cars/bmw/320/beehnh.html
import requests, re
lapa = requests.get("https://www.ss.lv/msg/lv/transport/cars/bmw/320/beehnh.html")
cena = re.search(r'[-+]?\d+\s[-+]?\d+\s€',lapa.text)
print(cena.group(0))