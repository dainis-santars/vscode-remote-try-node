import random
kp = random.randint(1,500)
print(kp)