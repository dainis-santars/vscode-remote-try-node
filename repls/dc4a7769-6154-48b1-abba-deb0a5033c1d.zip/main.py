import random
n_rindas = 10
m_kolonnas = 10
a = [[0] * m_kolonnas for i in range(n_rindas)]
for i in range(n_rindas):
  for j in range(m_kolonnas):
    a[i][j] = random.choice([" ","💣"])
for row in a:
  print(' '.join([str(elem) for elem in row]))

r = (int(input("Ievadi rindas numuru: ")))
k = (int(input("Ievadi kolonnas numuru: ")))
i = r - 1
j = k - 1
print(r,k,i,j)
print(a[i][j])