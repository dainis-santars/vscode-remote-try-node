import requests
from bs4 import BeautifulSoup
page = requests.get("https://lsm.lv/")
# print(page)
soup = BeautifulSoup(page.text, "html.parser")
# print(soup)
v = soup.find("section", class_="globalnav__item globalnav__item-today")
# print(v)
r = v.find_all("p")[1]
d = v.find_all("p")[0]
# print(r)
print("Šodien ir",d.get_text())
print(r.get_text())